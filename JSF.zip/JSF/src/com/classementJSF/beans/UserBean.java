package com.classementJSF.beans;

import java.io.Serializable;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean(name = "userbean")
@RequestScoped
public class UserBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String pseudo = null;
	private String mdp;
	private List<String> region;
	private String mRegion;

	// Mettre par d�faut en passant par le bean
	// @ManagedProperty(name = "mRegion", value = "Rhone-Alpes")

	// Constructeur vide
	public UserBean() {
	}

	public String getPseudo() {
		return pseudo;
	}

	public void setPseudo(String pseudo) {
		this.pseudo = pseudo;
	}

	public String getMdp() {
		return mdp;
	}

	public void setMdp(String mdp) {
		this.mdp = mdp;
	}

	public List<String> getRegion() {
		return region;
	}

	public void setRegion(List<String> region) {
		this.region = region;
	}

	public String getmRegion() {
		return mRegion;
	}

	public void setmRegion(String mRegion) {
		this.mRegion = mRegion;
	}

	public String navigation() {
		if (this.pseudo.length() != 0 && this.pseudo.equalsIgnoreCase(this.mdp)) {
			return "montre";
		} else {
			return "content_login";
		}
	}
}

// public boolean verification() {
// if (this.mdp.length() >= 8) {
// return true;
// }
// return false;
// }
